from django.apps import AppConfig


class FavoriteAnimalConfig(AppConfig):
    name = 'Favorite_Animal'
